# mkdocs-extras

CSS + config snippets to bring the editorial design system from
[tysonswetnam.com](https://tysonswetnam.com) into the Zensical/Material
MkDocs documentation pages.

## Files

- **`extra.css`** — drop-in stylesheet that overrides Material's tokens,
  typography, header, sidebars, tables, code blocks, admonitions, and
  footer. Tag the `<html>` element via the standard Material palette
  toggle to flip light/dark.
- **`mkdocs.yml.snippet`** — the small additions needed in your
  `mkdocs.yml` to load Google Fonts, register the custom palettes, and
  wire up the CSS.
- **`docs-preview.html`** — static preview of how a typical doc page
  will look once the override is applied. Open it directly to verify.

## Install

1. Copy `extra.css` to `docs/stylesheets/extra.css` in the MkDocs site.
2. Merge the contents of `mkdocs.yml.snippet` into your `mkdocs.yml`.
3. Run `mkdocs serve` and navigate to any inner page to verify.
4. Use the toggle in the header to switch between `tls-light` and
   `tls-dark`.

## What it does

- Replaces Material's blue/indigo system with the warm-paper / ink /
  ochre palette from the landing site.
- Pairs **EB Garamond** (display + italic ledes) with **Inter Tight**
  (body) and **JetBrains Mono** (eyebrows, code, captions).
- Re-styles every Material surface (header, tabs, sidebars, TOC, search,
  admonitions, tables, code, footer) without removing them, so the
  navigation, search, and Mermaid diagrams keep working.
- Adds a `§` mark to all `<h2>` and a small `TLS` chip to the header
  brand so the docs feel of a piece with the landing site.

## What it preserves

- Material's left sidebar nav
- Right-rail table of contents
- Search overlay (re-skinned)
- Tabs nav
- Admonition icons (re-toned)
- Mermaid / diagram support (untouched)
