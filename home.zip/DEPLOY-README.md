# tysonswetnam.com — deploy package

This zip contains two deliverables:

1. **A custom landing site** (`index.html`, `publications.html`, plus styles & React components) — a new editorial design for the front door of tysonswetnam.com.
2. **An MkDocs Material theme override** (`mkdocs-extras/`) — drop-in CSS that restyles the existing Zensical/Material docs to match the landing site's design system.

You can ship one or both. Below is what to do with each.

---

## 1. The landing site

Files (project root):

```
index.html              ← landing page (React on CDN, no build step)
publications.html       ← full publication portfolio
style.css               ← shared design tokens & layout
data.jsx                ← projects, publications, notes, collaborators
sections.jsx            ← React components for index sections
publications-data.jsx   ← full publication list (41 entries)
publications-app.jsx    ← React app for publications.html
```

These are static files. There's no build step — open `index.html` in a browser and it works. To deploy:

### Option A — host as the site root, MkDocs at `/docs/`

Most direct path. The repo's MkDocs build produces a static site at `site/` (or wherever `site_dir` points). You'd:

1. Build the MkDocs site as usual: `mkdocs build` → `site/`
2. Copy `site/` → `docs/` inside the deployed bundle
3. Drop `index.html`, `publications.html`, `style.css`, and the four `*.jsx` files at the bundle root
4. Update internal links in the landing page's nav from `index.html#research` etc. to point at `/docs/research/` (these references are in `sections.jsx` and `publications-app.jsx`)

Deploy the resulting bundle to GitHub Pages, Netlify, Cloudflare Pages — anywhere that serves static files.

### Option B — keep MkDocs at the root, host the landing page on a subdomain

Easier, no build coordination:

1. Push the landing page files to a separate repo (e.g. `tyson-swetnam/landing`)
2. Deploy via Netlify / Cloudflare Pages
3. Point `tysonswetnam.com` at the landing page; move the docs to `docs.tysonswetnam.com`

### Option C — port the landing page into a MkDocs `overrides/home.html`

Most integrated, most work. The landing page becomes a Material theme override at `overrides/home.html`. MkDocs renders it as the homepage, the rest of the docs render normally underneath. I can do this conversion in a follow-up if you want — it requires translating the React components into a static HTML/CSS render plus a small amount of inline JS.

---

## 2. The MkDocs theme override

Files in `mkdocs-extras/`:

```
extra.css               ← drop-in stylesheet, restyles all Material surfaces
mkdocs.yml.snippet      ← additions for your existing mkdocs.yml
docs-preview.html       ← static preview page (open in a browser to see)
README.md               ← detailed install notes
```

To install:

1. Copy `mkdocs-extras/extra.css` → `docs/stylesheets/extra.css` in your `tyson-swetnam/home` repo
2. Merge the contents of `mkdocs-extras/mkdocs.yml.snippet` into `mkdocs.yml`
3. Run `mkdocs serve` and verify on a typical inner page
4. Commit & push — GitHub Actions / your existing CI will rebuild and redeploy

What it changes:

- Replaces Material's blue/indigo defaults with the warm-paper / ink / ochre palette
- Pairs EB Garamond (display) + Inter Tight (body) + JetBrains Mono (eyebrows, code)
- Re-skins header, tabs, sidebars, TOC, search, admonitions, tables, code blocks, footer
- Adds a `§` mark to all `<h2>` and a small `TLS` chip to the header brand
- Light + dark schemes wired into Material's palette toggle

What it preserves:

- Material's left sidebar nav
- Right-rail table of contents
- Search overlay (re-skinned)
- Tabs nav
- Admonition icons (re-toned)
- Mermaid / diagram support (untouched)

---

## What I'd recommend

If you want one repo / one deploy: **Option C** (port landing into MkDocs overrides) — happy to do that conversion.

If you want fastest path to live: **Option B** (subdomain split) + ship the MkDocs override now.

---

## Manifest

```
DEPLOY-README.md           ← this file
index.html
publications.html
style.css
data.jsx
sections.jsx
publications-data.jsx
publications-app.jsx
mkdocs-extras/
  extra.css
  mkdocs.yml.snippet
  docs-preview.html
  README.md
```

Plus any starter components (`*.jsx` for design canvas, etc.) used during development — those are not needed for deploy and can be ignored or deleted.
