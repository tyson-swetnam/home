const { useState, useEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "light",
  "accent": "ochre",
  "hero": "default"
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweak] = window.useTweaks(TWEAK_DEFAULTS);
  const [active, setActive] = useState('hero');

  // Apply theme/accent/hero variants to <html>
  useEffect(() => {
    document.documentElement.dataset.theme = tweaks.theme;
    document.documentElement.dataset.accent = tweaks.accent;
    document.documentElement.dataset.hero = tweaks.hero;
  }, [tweaks]);

  // Scroll-spy
  useEffect(() => {
    const ids = ['hero','research','publications','teaching','os','notes','cv'];
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(e => { if (e.isIntersecting) setActive(e.target.id); });
    }, { threshold: [0.3], rootMargin: '-20% 0px -50% 0px' });
    ids.forEach(id => { const el = document.getElementById(id); if (el) obs.observe(el); });
    return () => obs.disconnect();
  }, []);

  const onNav = (id) => {
    const el = document.getElementById(id);
    if (el) window.scrollTo({ top: el.offsetTop - 64, behavior: 'smooth' });
  };

  const T = window;

  return (
    <>
      <T.TopBar active={active} onNav={onNav}
        theme={tweaks.theme}
        setTheme={(v) => setTweak('theme', v)} />
      <main>
        <T.Hero />
        <T.ResearchSection />
        <T.PublicationsSection />
        <T.TeachingSection />
        <T.OpenScienceSection />
        <T.NotesSection />
        <T.CvSection />
      </main>
      <T.Foot />

      <window.TweaksPanel title="Tweaks">
        <window.TweakSection title="Theme">
          <window.TweakRadio label="Mode" value={tweaks.theme}
            onChange={v => setTweak('theme', v)}
            options={[{value:'light',label:'Light'},{value:'dark',label:'Dark'}]} />
        </window.TweakSection>

        <window.TweakSection title="Accent">
          <window.TweakSelect label="Color" value={tweaks.accent}
            onChange={v => setTweak('accent', v)}
            options={[
              {value:'ochre', label:'Ochre (default)'},
              {value:'forest', label:'Forest'},
              {value:'indigo', label:'Indigo'},
              {value:'red', label:'Arizona red'},
              {value:'mono', label:'Monochrome'},
            ]} />
        </window.TweakSection>

        <window.TweakSection title="Hero layout">
          <window.TweakRadio label="Variant" value={tweaks.hero}
            onChange={v => setTweak('hero', v)}
            options={[
              {value:'default', label:'Editorial split'},
              {value:'stack', label:'Stacked'},
              {value:'marquee', label:'Marquee'},
            ]} />
        </window.TweakSection>
      </window.TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
