const { useState, useMemo, useEffect } = React;

function PubItem({ p }) {
  const { TAG_LABELS } = window.PUBS_DATA;
  const href = p.doi ? `https://doi.org/${p.doi}` : (p.url || '#');
  return (
    <a className="pub" href={href} target="_blank" rel="noreferrer">
      <div className="num">№ {String(p.n).padStart(2,'0')}</div>
      <div>
        <div className="title">{p.title}{p.featured && <span style={{marginLeft:10, fontFamily:'var(--mono)', fontSize:10, letterSpacing:'0.14em', color:'var(--accent)', textTransform:'uppercase', verticalAlign:'middle'}}>★ featured</span>}</div>
        <div className="meta">{p.authors} · in <em>{p.venue}</em></div>
        <div className="tags">{p.tags.map(t => `· ${TAG_LABELS[t] || t}`).join(' ')}</div>
      </div>
      <div className="year">
        <div className="numeral">{p.year}</div>
        <span className="doi">{p.doi ? 'doi ↗' : (p.url ? 'link ↗' : '')}</span>
      </div>
    </a>
  );
}

function App() {
  const { ALL_PUBS, TAG_LABELS } = window.PUBS_DATA;
  const [query, setQuery] = useState('');
  const [activeTags, setActiveTags] = useState([]);
  const [sort, setSort] = useState('newest');
  const [theme, setTheme] = useState('light');

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.documentElement.dataset.accent = 'ochre';
  }, [theme]);

  // Tag counts
  const tagCounts = useMemo(() => {
    const counts = {};
    ALL_PUBS.forEach(p => p.tags.forEach(t => { counts[t] = (counts[t] || 0) + 1; }));
    return counts;
  }, []);

  const tagOrder = useMemo(() =>
    Object.keys(TAG_LABELS).filter(t => tagCounts[t] > 0).sort((a,b) => tagCounts[b] - tagCounts[a]),
  []);

  const toggleTag = (t) => setActiveTags(s => s.includes(t) ? s.filter(x => x !== t) : [...s, t]);

  const filtered = useMemo(() => {
    let list = ALL_PUBS.slice();
    if (activeTags.length) {
      list = list.filter(p => activeTags.every(t => p.tags.includes(t)));
    }
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(p =>
        p.title.toLowerCase().includes(q) ||
        p.authors.toLowerCase().includes(q) ||
        p.venue.toLowerCase().includes(q) ||
        (p.doi || '').toLowerCase().includes(q)
      );
    }
    if (sort === 'newest') list.sort((a,b) => b.year - a.year || b.n - a.n);
    if (sort === 'oldest') list.sort((a,b) => a.year - b.year || a.n - b.n);
    if (sort === 'featured') list.sort((a,b) => (b.featured?1:0) - (a.featured?1:0) || b.year - a.year);
    return list;
  }, [activeTags, query, sort]);

  // Group by year (only when sorted by year)
  const grouped = useMemo(() => {
    if (sort === 'featured') return null;
    const g = {};
    filtered.forEach(p => { (g[p.year] = g[p.year] || []).push(p); });
    const years = Object.keys(g).map(Number).sort((a,b) => sort === 'oldest' ? a - b : b - a);
    return years.map(y => ({ year: y, items: g[y] }));
  }, [filtered, sort]);

  // Stats
  const stats = useMemo(() => {
    const years = ALL_PUBS.map(p => p.year);
    return {
      total: ALL_PUBS.length,
      first: Math.min(...years),
      last: Math.max(...years),
      firstAuthor: ALL_PUBS.filter(p => p.authors.startsWith('Swetnam')).length,
    };
  }, []);

  return (
    <>
      {/* Top bar — same shape as main site */}
      <header className="topbar">
        <div className="shell topbar-inner">
          <div className="brand">
            <span className="initials">TLS</span>
            <span className="name"><a href="index.html">T.L. Swetnam</a></span>
          </div>
          <nav className="primary">
            <a href="index.html#hero">Home</a>
            <a href="index.html#research">Research</a>
            <a href="publications.html" className="active">Publications</a>
            <a href="index.html#teaching">Teaching</a>
            <a href="index.html#os">Open Science</a>
            <a href="index.html#notes">Field Notes</a>
            <a href="index.html#cv">CV</a>
          </nav>
          <div className="tools">
            <button className="icon-btn" title="Toggle theme" onClick={() => setTheme(t => t === 'dark' ? 'light' : 'dark')}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
                {theme === 'dark'
                  ? <><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></>
                  : <path d="M21 12.79A9 9 0 1 1 11.21 3a7 7 0 0 0 9.79 9.79z"/>}
              </svg>
            </button>
          </div>
        </div>
      </header>

      <section className="pubs-hero">
        <div className="shell">
          <div className="eyebrow"><span className="dot" style={{color:'var(--accent)'}}>●</span>&nbsp;&nbsp;§ 02 / Selected Work · The full list</div>
          <h1>Publications.</h1>
          <p className="lede">A complete portfolio of papers, reports, preprints, and book chapters — most peer-reviewed, all linked to a DOI or canonical URL where one exists.</p>

          <div className="stats">
            <div className="stat">
              <div className="num">{stats.total}</div>
              <div className="lab">Total entries</div>
            </div>
            <div className="stat">
              <div className="num">{stats.firstAuthor}</div>
              <div className="lab">First-author</div>
            </div>
            <div className="stat">
              <div className="num">{stats.first}</div>
              <div className="lab">First publication</div>
            </div>
            <div className="stat">
              <div className="num">{stats.last}</div>
              <div className="lab">Most recent</div>
            </div>
          </div>
        </div>
      </section>

      <div className="pubs-controls">
        <div className="shell">
          <div className="pubs-controls-inner">
            <div className="pubs-search">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35"/></svg>
              <input type="text" value={query} onChange={e => setQuery(e.target.value)} placeholder="Search title, author, venue, DOI…" />
              {query && <button className="icon-btn" style={{width:24, height:24}} onClick={() => setQuery('')} title="Clear">×</button>}
            </div>
            <div className="pubs-sort">
              <div className={`opt ${sort === 'newest' ? 'active' : ''}`} onClick={() => setSort('newest')}>Newest</div>
              <div className={`opt ${sort === 'oldest' ? 'active' : ''}`} onClick={() => setSort('oldest')}>Oldest</div>
              <div className={`opt ${sort === 'featured' ? 'active' : ''}`} onClick={() => setSort('featured')}>Featured</div>
            </div>
          </div>
          <div className="pubs-tags">
            <div className={`chip ${activeTags.length === 0 ? 'active' : ''}`} onClick={() => setActiveTags([])}>All<span className="count">{ALL_PUBS.length}</span></div>
            {tagOrder.map(t => (
              <div key={t} className={`chip ${activeTags.includes(t) ? 'active' : ''}`} onClick={() => toggleTag(t)}>
                {TAG_LABELS[t]}<span className="count">{tagCounts[t]}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <section className="pubs-list">
        <div className="shell">
          {filtered.length === 0 && (
            <div className="empty">No publications match those filters.</div>
          )}

          {grouped ? grouped.map(g => (
            <div key={g.year} className="pubs-year-group">
              <div className="pubs-year-head">
                <div className="y">{g.year}</div>
                <div className="lab">{g.items.length} {g.items.length === 1 ? 'entry' : 'entries'}</div>
              </div>
              <div className="pub-list">
                {g.items.map(p => <PubItem key={p.n} p={p} />)}
              </div>
            </div>
          )) : (
            <div className="pub-list">
              {filtered.map(p => <PubItem key={p.n} p={p} />)}
            </div>
          )}
        </div>
      </section>

      <footer>
        <div className="shell footer-grid">
          <div>
            <h4>Colophon</h4>
            <div className="colophon"><em>Set in EB Garamond &amp; Inter Tight.</em> Citations sourced from the canonical record at tyson-swetnam/home and verified DOIs.</div>
          </div>
          <div>
            <h4>Sections</h4>
            <ul>
              <li><a href="index.html#research">Research</a></li>
              <li><a href="publications.html">Publications</a></li>
              <li><a href="index.html#teaching">Teaching</a></li>
              <li><a href="index.html#os">Open Science</a></li>
              <li><a href="index.html#notes">Field Notes</a></li>
              <li><a href="index.html#cv">CV</a></li>
            </ul>
          </div>
          <div>
            <h4>Elsewhere</h4>
            <ul>
              <li><a href="https://orcid.org/0000-0002-6639-7181" target="_blank" rel="noreferrer">ORCID</a></li>
              <li><a href="https://scholar.google.com/citations?user=nanIeAYAAAAJ" target="_blank" rel="noreferrer">Google Scholar</a></li>
              <li><a href="https://github.com/tyson-swetnam" target="_blank" rel="noreferrer">GitHub</a></li>
            </ul>
          </div>
        </div>
        <div className="shell footer-bottom">
          <span>© 2019–2026 Tyson Lee Swetnam</span>
          <span>{stats.total} entries · revision 47.f3a</span>
        </div>
      </footer>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
